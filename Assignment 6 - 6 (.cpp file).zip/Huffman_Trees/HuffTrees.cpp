// HuffTrees.cpp : Defines the entry point for the console application.
//

#include "Huffman_Tree.h"
#include <iostream>


int main()
{
	Huff_Data space(143, ' ');
	Huff_Data five(1, "five");
	Huff_Data little(5, "little");
	Huff_Data monkeys(10, "monkeys");
	Huff_Data jumping(10, "jumping");
	Huff_Data on(10, "on");
	Huff_Data the(20, "the");
	Huff_Data bed(10, "bed");
	Huff_Data one(5, "one");
	Huff_Data fell(5, "fell");
	Huff_Data down(5, "down");
	Huff_Data and(10, "and");
	Huff_Data bumped(5, "bumped");
	Huff_Data his(3, "his");
	Huff_Data her(2, "her");
	Huff_Data head(3, "head:);
	Huff_Data mama(5, "Mama");
	Huff_Data called(5, "called");
	Huff_Data doctor(10, "doctor");
	Huff_Data said(5, "said");
	Huff_Data no(5, "no");
	Huff_Data more(5, "more");
	Huff_Data four(1, "Four");
	Huff_Data three(1, "Three");
	Huff_Data two(1, "Two");
	Huff_Data exclamation(5, "!");
	
	
	std::ostringstream code;
	std::vector<Huff_Data> huff_Data {space,five,little,monkeys,jumping,on,the,bed,one,fell,down,and,bumped,his,head,Mama,called,doctor,said,no,more,four,three,two,exclamation};
	Huffman_Tree huff_tree;
	huff_tree.build_tree(huff_Data);
	huff_tree.print_code(code);
	std::string result = code.str();
	std::cout << result;

	result = huff_tree.decode("010");

	return 0;
}

